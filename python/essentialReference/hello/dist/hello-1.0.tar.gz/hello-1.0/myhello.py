def hello():
	print "Hello"

