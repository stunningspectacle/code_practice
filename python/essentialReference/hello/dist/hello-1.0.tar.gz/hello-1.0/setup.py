#!/usr/bin/python

from distutils.core import setup

setup(name = "hello",
		version = "1.0",
		scripts = ["myhello.py"])
