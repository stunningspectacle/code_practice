#!/bin/sh
date
#adb devices
#board_ids=`adb devices | cut -f 1 | sort`
#for board_id in $board_ids;
board_id=$1
#do
echo "[Board: $board_id]"
echo "Current Uptime:"
adb -s $board_id shell uptime
echo "~~~~~~~ANR issues~~~~~~~ "
echo ""
adb -s $board_id shell "cat /data/logs/history*" | grep ANR
echo ""
echo "~~~~~~~JAVACRASH issues~~~~~~~"
echo ""
adb -s $board_id shell "cat /data/logs/history*" | grep JAVACRASH
echo ""
echo "~~~~~~~TOMBSTONE~~~~~~~"
echo ""
adb -s $board_id shell "cat /data/logs/history*" | grep TOMBSTONE
echo ""
echo "~~~~~~~IPANIC~~~~~~~"
echo ""
adb -s $board_id shell "cat /data/logs/history*" | grep IPANIC
echo ""
echo "~~~~~~~REBOOT~~~~~~~"
echo ""
adb -s $board_id shell "cat /data/logs/history*" | grep REBOOT
echo ""
echo "~~~~~~~UPTIME~~~~~~~"
echo ""
adb -s $board_id shell "cat /data/logs/history*" | grep UPTIME
echo ""
echo ""
echo "-------State in All-------"
echo "ANR issues "
adb -s $board_id shell "cat /data/logs/history*" | grep -c ANR
echo "JAVACRASH issues"
adb -s $board_id shell "cat /data/logs/history*" | grep -c JAVACRASH
echo "TOMBSTONE "
adb -s $board_id shell "cat /data/logs/history*" | grep -c TOMBSTONE
echo "IPANIC"
adb -s $board_id shell "cat /data/logs/history*" | grep -c IPANIC
echo "REBOOT"
adb -s $board_id shell "cat /data/logs/history*" | grep -c REBOOT
echo "UPTIME"
adb -s $board_id shell "cat /data/logs/history*" | grep -c UPTIME
date
echo "=========================================================================="
#done
